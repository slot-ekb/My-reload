#!/bin/bash
cd "$(dirname "$0")"; BASE="$(pwd)"
# майнеры этого пакета (по пути bin/epic-miner — чужие паки не тронем)
for s in $(screen -ls 2>/dev/null | grep -oE '[0-9]+\.pcu[0-9]+'); do screen -S "$s" -X quit; done
pkill -f "$BASE/bin/epic-miner" 2>/dev/null
# прокси
screen -S proxycu-px -X quit 2>/dev/null
pkill -f "$BASE/bin/epic_proxy.py" 2>/dev/null
pkill -f "bin/epic_proxy.py $NODE" 2>/dev/null
echo "proxycu остановлен (майнеры + прокси)"

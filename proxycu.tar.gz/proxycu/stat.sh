#!/bin/bash
# Одноразовый статус (без watch) — для HiveOS "Execute command" или быстрого просмотра.
cd "$(dirname "$0")"; . ./config.env 2>/dev/null; NPORT="${NODE##*:}"
echo "===== PROXYCU $(hostname) ====="
pgrep -f bin/epic_proxy.py >/dev/null && echo "прокси           : РАБОТАЕТ" || echo "прокси           : *** СТОП ***"
echo "воркеров->прокси : $(ss -Htn state established "( dport = :$PROXY_PORT )" 2>/dev/null | wc -l)"
echo "прокси->нода     : $(ss -Htn state established "( dport = :$NPORT )" 2>/dev/null | wc -l)  (нода $NODE)"
echo "--- учёт прокси ---"
grep 'СТАТ' logs/proxy.log 2>/dev/null | tail -1 | sed 's/^[0-9:]* СТАТ/ /'
echo "--- хешрейт cuckoo ---"
for f in inst/*/miner.log; do grep -oE 'at [0-9.]+ gps' "$f" 2>/dev/null | awk '$2>0{v=$2} END{if(v!="")print v}'; done | awk '{s+=$1;n++} END{printf " %.0f gps (%d проц)\n",s,n}'

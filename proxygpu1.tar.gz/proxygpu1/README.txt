proxygpu1 — GPU-пакет (прокси :3401 + GPU-майнеры). Логин на ноде: <hostname>-gpu.
Настройки: config.env (RANGE, MINER=range|orig, LOGS=on|off, LOG_MAX_MB, PROXYLOG).
Запуск:  ./all-start.sh  (или отдельно ./proxy-start.sh / ./miners-start.sh)
Стоп:    ./all-stop.sh   (или ./proxy-stop.sh / ./miners-stop.sh)
Меняешь config.env -> рестарт МАЙНЕРОВ (прокси трогать не надо).

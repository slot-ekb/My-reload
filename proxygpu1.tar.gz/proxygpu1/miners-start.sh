#!/bin/bash
BASE="$(cd "$(dirname "$0")"&&pwd)"; . "$BASE/config.env"
NG=$(nvidia-smi -L 2>/dev/null | wc -l); [ "$NG" -lt 1 ] && NG=1
N=${INSTANCES:-0}; [ "$N" -le 0 ] && N=$NG
. "$BASE/aff.sh" "$NG" >/dev/null 2>&1 || true; IFS=',' read -ra GA <<< "${GPUSET:-}"
export EPIC_RANGE=${RANGE:-1}; MB="$BASE/bin/epic-miner-${MINER:-range}"
for ((i=0;i<N;i++)); do
  D="$BASE/instances/ecuk$i"; mkdir -p "$D"
  if [ "$LOGS" = on ] && [ "$i" = 0 ]; then LT=true; else LT=false; fi
  cat > "$D/epic-miner.toml" <<TOML
[logging]
log_to_stdout = false
log_to_file = $LT
file_log_level = "Info"
stdout_log_level = "Info"
log_file_path = "$D/miner.log"
log_file_append = false
[mining]
algorithm = "Cuckoo"
run_tui = false
stratum_server_addr = "127.0.0.1:$PROXY_PORT"
stratum_server_tls_enabled = false
miner_plugin_dir = "$BASE/plugins"
[mining.randomx_config]
threads = 1
jit = true
large_pages = false
hard_aes = true
[[mining.gpu_config]]
device = $i
driver = 2
[[mining.miner_plugin_config]]
plugin_name = "cuckatoo_lean_cuda_19"
[mining.miner_plugin_config.parameters]
device = $i
TOML
  PIN=""; [ -n "${GA[$i]}" ] && PIN="taskset -c ${GA[$i]} "
  screen -S "ecuk$i" -X quit 2>/dev/null
  screen -dmS "ecuk$i" bash -c "cd '$D'; export LD_LIBRARY_PATH='$BASE/lib'; export EPIC_RANGE=${RANGE:-1}; while true; do ${PIN}'$MB' -c epic-miner.toml; sleep 3; done"
done
if [ "$LOGS" = on ]; then screen -S logwatch-gpu -X quit 2>/dev/null; screen -dmS logwatch-gpu "$BASE/logwatch.sh" "$BASE/instances/ecuk0/miner.log"; fi
echo "GPU-майнеры: карт=$N бинарь=${MINER} RANGE=${RANGE} LOGS=${LOGS}"

#!/usr/bin/env python3
# Вотчер окон Epic. Коннектится к прокси КАК ВОРКЕР (только читает задания),
# определяет текущее алго окна мгновенно и на СМЕНЕ окна морозит/размораживает
# "чужой" майнер через внешние команды STOP/START. Прокси НЕ трогает.
# Настройки берутся из окружения (run.sh их экспортирует из config.env):
#   PROXY=127.0.0.1:3401     адрес прокси
#   FREEZE_ON="cuckoo"       список алго (через пробел), в чьих окнах морозим чужой майнер
#   STOP=/opt/stop           команда заморозки чужого майнера
#   START=/opt/start         команда разморозки
import socket, json, os, sys, time, subprocess, signal

PROXY = os.environ.get("PROXY", "127.0.0.1:3401")
FREEZE_ON = set(os.environ.get("FREEZE_ON", "cuckoo").split())
STOP = os.environ.get("STOP", "/opt/stop")
START = os.environ.get("START", "/opt/start")
HOST = PROXY.split(":")[0]
PORT = int(PROXY.split(":")[1]) if ":" in PROXY else 3401

state = None  # None | "frozen" | "running"

def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)

def run(cmd):
    try:
        subprocess.run(cmd, shell=False, timeout=15)
    except Exception as e:
        log("ошибка выполнения", cmd, e)

def set_frozen():
    global state
    if state != "frozen":
        log("окно морозим -> STOP:", STOP)
        run([STOP]); state = "frozen"

def set_running():
    global state
    if state != "running":
        log("окно размораживаем -> START:", START)
        run([START]); state = "running"

def cleanup(*_):
    # при выходе ВСЕГДА размораживаем, чтобы не оставить чужой майнер висеть замороженным
    log("выход — размораживаю на всякий случай")
    run([START])
    sys.exit(0)

signal.signal(signal.SIGTERM, cleanup)
signal.signal(signal.SIGINT, cleanup)

def handle_algo(algo):
    if algo in FREEZE_ON:
        set_frozen()
    else:
        set_running()

def session():
    s = socket.create_connection((HOST, PORT), timeout=10)
    s.settimeout(30)
    try:
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    except Exception:
        pass
    # представиться воркером, чтобы прокси слал задания
    s.sendall(b'{"id":"0","jsonrpc":"2.0","method":"login","params":{"login":"switch","pass":"","agent":"switch"}}\n')
    s.sendall(b'{"id":"1","jsonrpc":"2.0","method":"getjobtemplate","params":{"algorithm":"any"}}\n')
    log("подключён к прокси", PROXY, "| FREEZE_ON =", " ".join(sorted(FREEZE_ON)) or "(пусто)")
    buf = b""; last_ka = time.time()
    while True:
        if time.time() - last_ka > 20:
            try: s.sendall(b'{"id":"k","jsonrpc":"2.0","method":"keepalive"}\n')
            except Exception: return
            last_ka = time.time()
        try:
            data = s.recv(8192)
        except socket.timeout:
            continue
        if not data:
            return
        buf += data
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            line = line.strip()
            if not line: continue
            try: msg = json.loads(line)
            except Exception: continue
            p = msg.get("params")
            if not isinstance(p, dict) or "algorithm" not in p:
                p = msg.get("result")
            if isinstance(p, dict) and "algorithm" in p:
                handle_algo(p["algorithm"])

def main():
    log("switch старт | PROXY", PROXY, "| STOP", STOP, "| START", START)
    while True:
        try:
            session()
        except Exception as e:
            log("нет связи с прокси, ретрай через 3с:", e)
        # потеряли сигнал окна — размораживаем (не держим чужой майнер вслепую замороженным)
        set_running()
        time.sleep(3)

main()

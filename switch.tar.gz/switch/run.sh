#!/bin/bash
# Запуск вотчера окон (switch) с авто-рестартом. Прокси не трогает.
cd /opt/switch
. ./config.env
export PROXY FREEZE_ON STOP START
# один экземпляр
pkill -f '/opt/switch/switch.py' 2>/dev/null; sleep 1
setsid bash -c 'while true; do python3 /opt/switch/switch.py; sleep 3; done' >/opt/switch/switch.log 2>&1 </dev/null &
sleep 1
echo "switch запущен | PROXY=$PROXY | FREEZE_ON=\"$FREEZE_ON\" | STOP=$STOP START=$START"
echo "лог: /opt/switch/switch.log"
tail -4 /opt/switch/switch.log 2>/dev/null

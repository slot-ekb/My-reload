#!/bin/bash
# Запуск вотчера окон (switch) в screen "switch" с авто-рестартом. Прокси не трогает.
cd /opt/switch
. ./config.env
export PROXY FREEZE_ON STOP START
# один экземпляр
screen -S switch -X quit 2>/dev/null; pkill -f '/opt/switch/switch.py' 2>/dev/null; sleep 1
screen -dmS switch bash -c 'while true; do python3 /opt/switch/switch.py >>/opt/switch/switch.log 2>&1; sleep 3; done'
sleep 1
echo "switch запущен в screen \"switch\" | PROXY=$PROXY | FREEZE_ON=\"$FREEZE_ON\" | STOP=$STOP START=$START"
echo "смотреть: screen -ls | grep switch   лог: /opt/switch/switch.log   подключиться: screen -r switch"
tail -4 /opt/switch/switch.log 2>/dev/null

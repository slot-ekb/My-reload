#!/bin/bash
# Остановка вотчера окон + гарантированная разморозка чужого майнера.
cd /opt/switch 2>/dev/null
. ./config.env 2>/dev/null
# убить и обёртку-рестарт, и сам вотчер
pkill -f 'while true; do python3 /opt/switch/switch.py' 2>/dev/null
pkill -f '/opt/switch/switch.py' 2>/dev/null
sleep 1
# на всякий случай разморозить чужой майнер, чтобы не остался висеть
${START:-/opt/start} 2>/dev/null
echo "switch остановлен, чужой майнер разморожен (START вызван)"

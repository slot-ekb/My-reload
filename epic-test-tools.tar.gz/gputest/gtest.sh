#!/bin/bash
# GPU-тест. Настраивай аргументами. Пак останови заранее (в /opt/epic-cuckatoo: ./stop.sh)
# Usage: ./gtest.sh [карт] [секунд] [pin_base] [ht_offset] [tpb] [blk]
NG=${1:-6}; SECS=${2:-20}; PB=${3:-14}; HT=${4:-28}; TPB=${5:-256}; BLK=${6:-128}
cd "$(dirname "$0")"; PLUG=./cuckatoo_lean_cuda_19.cuckooplugin; rm -f /tmp/g_*.txt
echo "GPU: карт=$NG сек=$SECS pin_base=$PB ht=$HT tpb=$TPB blk=$BLK"
for ((d=0; d<NG; d++)); do
  CORE=$((PB+d)); if [ "$HT" -gt 0 ]; then SET="${CORE},$((CORE+HT))"; else SET="$CORE"; fi
  echo "  карта $d -> ядра $SET"
  taskset -c $SET ./harness5 "$PLUG" $d $SECS $TPB $BLK >/tmp/g_$d.txt 2>&1 &
done
wait
echo "--- по секундам смотри в /tmp/g_N.txt ; ИТОГ: ---"
grep -h ИТОГ /tmp/g_*.txt | sort
grep -h ИТОГ /tmp/g_*.txt | grep -oE 'ИТОГ [0-9]+'|grep -oE '[0-9]+'|awk '{s+=$1}END{printf ">>> GPU Σ = %d g/s\n",s}'

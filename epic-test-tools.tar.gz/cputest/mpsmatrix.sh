#!/bin/bash
# Сравнение lean vs mean, 1 и 3 потока на карте 0, без MPS и с MPS (изолированный).
OUT=/opt/epic-miner-src/build_out
MEAN="$OUT/mean_bench19"; LEAN="$OUT/lean_bench19"
DEV=0
export CUDA_VISIBLE_DEVICES=$DEV
PIPE=/tmp/mps_test/pipe; LOG=/tmp/mps_test/log; mkdir -p "$PIPE" "$LOG"

run() { # bin N mps R name
  local BIN=$1 N=$2 MPS=$3 R=$4 NM=$5
  if [ "$MPS" = 1 ]; then export CUDA_MPS_PIPE_DIRECTORY=$PIPE CUDA_MPS_LOG_DIRECTORY=$LOG; else unset CUDA_MPS_PIPE_DIRECTORY CUDA_MPS_LOG_DIRECTORY; fi
  local t0 t1 wall pids="" pw
  t0=$(date +%s.%N)
  for i in $(seq 1 $N); do "$BIN" -d $DEV -r $R >/dev/null 2>&1 & pids="$pids $!"; done
  sleep 1; pw=$(nvidia-smi --query-gpu=power.draw,utilization.gpu --format=csv,noheader,nounits -i $DEV 2>/dev/null | tr -d ' ')
  wait $pids; t1=$(date +%s.%N)
  wall=$(awk "BEGIN{printf \"%.2f\",$t1-$t0}")
  awk "BEGIN{printf \"%-6s N=%d MPS=%d | %5d графов за %5.2fs = %6.0f gps сумм | карта %sW/%s%%\n\", \"$NM\",$N,$MPS,$N*$R,$wall,$N*$R/$wall,\"${pw%%,*}\",\"${pw##*,}\"}"
}

echo "==================== MATRIX (карта $DEV) ===================="
run "$MEAN" 1 0 400  mean
run "$MEAN" 3 0 400  mean
echo "-- включаю MPS --"; nvidia-cuda-mps-control -d 2>/dev/null; sleep 1
run "$MEAN" 3 1 400  mean
echo "-- стоп MPS --"; echo quit | nvidia-cuda-mps-control 2>/dev/null; sleep 1
run "$LEAN" 1 0 4000 lean
run "$LEAN" 3 0 4000 lean
echo "-- включаю MPS --"; nvidia-cuda-mps-control -d 2>/dev/null; sleep 1
run "$LEAN" 3 1 4000 lean
echo "-- стоп MPS --"; echo quit | nvidia-cuda-mps-control 2>/dev/null
echo "==================== DONE ===================="

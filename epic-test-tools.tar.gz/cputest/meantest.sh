#!/bin/bash
# meantest.sh  <кол-во_инстансов>  [карта]  [графов_на_инстанс]
# Пример: bash /opt/cputest/meantest.sh 3 0      # 3 mean-потока на карте 0
N=${1:-2}; DEV=${2:-0}; R=${3:-3000}
BIN=/opt/epic-miner-src/build_out/mean_bench19
[ -x "$BIN" ] || { echo "нет бинаря $BIN"; exit 1; }
echo ">> $N mean-инстансов на карте $DEV, по $R графов"
t0=$(date +%s.%N); pids=""
for i in $(seq 1 $N); do
  "$BIN" -d "$DEV" -r "$R" > /opt/cputest/mt_$i.out 2>&1 &
  pids="$pids $!"
done
sleep 2
echo "=== загрузка по процессам (sm% на каждый PID), карта $DEV ==="
nvidia-smi pmon -c 3 -s um 2>/dev/null | awk -v d=$DEV 'NR<=2||$1==d'
echo "=== карта $DEV: ватты / util / память ==="
nvidia-smi --query-gpu=power.draw,utilization.gpu,memory.used --format=csv,noheader -i "$DEV"
wait $pids
t1=$(date +%s.%N)
wall=$(awk "BEGIN{printf \"%.2f\",$t1-$t0}")
graphs=$((N*R))
echo "=== ИТОГ: $N × $R = $graphs графов за ${wall}s ==="
awk "BEGIN{printf \"СУММАРНО %.0f gps (на инстанс ~%.0f)\n\", $graphs/$wall, $graphs/$wall/$N}"

#!/bin/bash
# CPU-тест. Usage: ./ctest.sh [воркеров] [nthreads] [секунд] [ядра] [плагин]
#   ядра:   набор taskset (20-27,48-55) или auto
#   плагин: stock | rebuild | tuned  (или путь к .cuckooplugin). По умолч. stock
NW=${1:-4}; NTH=${2:-2}; SECS=${3:-20}; CORES=${4:-20-27,48-55}; PL=${5:-stock}
cd "$(dirname "$0")"
case "$PL" in
  stock)   PLUG=./cuckatoo_mean_cpu_avx2_19.cuckooplugin ;;
  rebuild) PLUG=./mean19_rebuild.cuckooplugin ;;
  tuned)   PLUG=./mean19_tuned.cuckooplugin ;;
  *)       PLUG="$PL" ;;
esac
rm -f /tmp/c_*.txt
echo "CPU: воркеров=$NW nthreads=$NTH сек=$SECS ядра=$CORES плагин=$PL"
for ((w=0; w<NW; w++)); do
  if [ "$CORES" = auto ]; then ./harness5cpu "$PLUG" $NTH $SECS $w >/tmp/c_$w.txt 2>&1 &
  else taskset -c $CORES ./harness5cpu "$PLUG" $NTH $SECS $w >/tmp/c_$w.txt 2>&1 & fi
done
wait
grep -h ИТОГ /tmp/c_*.txt | sort
grep -h ИТОГ /tmp/c_*.txt | grep -oE 'ИТОГ [0-9.]+'|grep -oE '[0-9.]+'|awk '{s+=$1}END{printf ">>> CPU Σ = %.1f g/s\n",s}'

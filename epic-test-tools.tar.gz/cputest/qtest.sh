#!/bin/bash
# Быстрый CPU-тест. Usage: ./qtest.sh [воркеров] [nthreads] [секунд] [плагин] [ядра] [бинарь]
#   плагин: stock|rebuild   ядра: auto|0-13,20-41,48-55   бинарь: patch|stock
NW=${1:-4}; NTH=${2:-4}; SECS=${3:-15}; PL=${4:-stock}; CORES=${5:-auto}; BIN=${6:-patch}
cd /opt/cputest
./startfake.sh >/dev/null 2>&1
./run_epic_cpu.sh $NW $NTH "$CORES" $PL fake $BIN >/dev/null 2>&1
[ "$SECS" -lt 8 ] && echo "(меньше 8с не успевает — беру 10)" && SECS=10
echo "воркеров=$NW nthreads=$NTH плагин=$PL ядра=$CORES бинарь=$BIN — жду ${SECS}с..."
sleep $SECS
./readcpu.sh
./stopcpu.sh >/dev/null 2>&1
./stopfake.sh >/dev/null 2>&1
echo "(готово)"

#!/bin/bash
pkill -f fakestratum.py && echo "фейк-стратум остановлен" || echo "не был запущен"

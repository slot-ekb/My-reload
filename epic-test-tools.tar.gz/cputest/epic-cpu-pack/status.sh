#!/bin/bash
cd "$(dirname "$0")/inst" 2>/dev/null || { echo "не запущено"; exit; }
n=0
for d in w*/; do
  g=$(grep -oE 'at [0-9.]+ gps' "$d/miner.log" 2>/dev/null | tail -3 | grep -oE '[0-9.]+' | sort -n | tail -1)
  echo "$g"
done | awk '{s+=$1;n++} END{printf ">>> воркеров=%d  Σ ≈ %.0f gps  (0=пауза/старт)\n",n,s}'

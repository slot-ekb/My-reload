=== epic-cpu — CPU-майнер cuckatoo, для ферм БЕЗ видеокарт ===

1) Распаковать:   tar xzf epic-cpu-pack.tar.gz && cd epic-cpu-pack
2) Указать пул:   поправь STRATUM в config.env  (адрес:порт)
3) Запустить:     ./run.sh
4) Скорость:      ./status.sh
5) Стоп:          ./stop.sh

Настройки (config.env):
  STRATUM  — адрес:порт пула/ноды (главное)
  WORKERS  — 0 = по числу ядер (максимум). Или точное число.
  NTHREADS — держи 1 (масштаб дают воркеры, не потоки).
  CORES    — auto = все ядра; или диапазон "0-31".

Нужны на ферме: screen, taskset(util-linux). Всё остальное (либы) внутри архива.
Бинарь собран под GLIBC 2.18 — идёт на любой современной ферме.

--- Если при запуске ругается на libncursesw.so.5 / libtinfo.so.5 / libssl.so.1.1 ---
Значит на ферме нет этих старых либ. Поставь (Ubuntu 20.04 их имеет в репо):
   sudo apt install -y libncursesw5 libtinfo5 libssl1.1
Больше ничего бандлить не нужно — librandomx уже внутри.

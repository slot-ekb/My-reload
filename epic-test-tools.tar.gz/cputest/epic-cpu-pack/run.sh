#!/bin/bash
cd "$(dirname "$0")"; BASE="$(pwd)"; . ./config.env
export LD_LIBRARY_PATH="$BASE/lib:$LD_LIBRARY_PATH"
N=${WORKERS:-0}; [ "$N" -le 0 ] && N=$(nproc)
NTH=${NTHREADS:-1}; CORES=${CORES:-auto}
echo "CPU-майнинг: воркеров=$N nthreads=$NTH ядра=$CORES стратум=$STRATUM"
for ((w=0; w<N; w++)); do
  INST="$BASE/inst/w$w"; mkdir -p "$INST"
  cat > "$INST/epic-miner.toml" <<TOML
[logging]
log_to_stdout = false
log_to_file = true
file_log_level = "Info"
stdout_log_level = "Info"
log_file_path = "$INST/miner.log"
log_file_append = false
[mining]
algorithm = "Cuckoo"
run_tui = false
stratum_server_addr = "$STRATUM"
stratum_server_tls_enabled = false
$( [ -n "$LOGIN" ] && echo "stratum_server_login = \"$LOGIN\"" )
miner_plugin_dir = "$BASE/plugins"
[mining.randomx_config]
threads = 1
jit = true
large_pages = false
hard_aes = true
[[mining.gpu_config]]
device = 0
driver = 2
[[mining.miner_plugin_config]]
plugin_name = "cuckatoo_mean_cpu_avx2_19"
[mining.miner_plugin_config.parameters]
nthreads = $NTH
TOML
  screen -S "ecpu$w" -X quit >/dev/null 2>&1
  [ "$CORES" = auto ] && PIN="" || PIN="taskset -c $CORES "
  screen -dmS "ecpu$w" bash -c "cd '$INST'; export LD_LIBRARY_PATH='$BASE/lib'; while true; do ${PIN}'$BASE/epic-miner' -c epic-miner.toml; sleep ${RESTART_DELAY:-3}; done"
done
echo "запущено $N воркеров. Скорость: ./status.sh | стоп: ./stop.sh"

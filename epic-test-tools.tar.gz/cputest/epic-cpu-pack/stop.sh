#!/bin/bash
for s in $(screen -ls 2>/dev/null | grep -oE 'ecpu[0-9]+'); do screen -S "$s" -X quit; done
echo "остановлено"

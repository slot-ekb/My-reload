#!/bin/bash
# Тест CPU на ФЕЙК-ноде. Одна команда, после теста всё гаснет (и фейк тоже).
# Usage: ./test.sh [воркеров|auto] [секунд]
cd "$(dirname "$0")"; BASE="$(pwd)"
export LD_LIBRARY_PATH="$BASE/lib:$LD_LIBRARY_PATH"
NW=${1:-auto}; SECS=${2:-20}; PORT=3499
[ "$NW" = auto ] && NW=$(nproc)
[ "$SECS" -lt 10 ] 2>/dev/null && SECS=10
# 1) поднять фейк-ноду
pkill -f "fakestratum.py $PORT" 2>/dev/null; sleep 1
python3 fakestratum.py $PORT >/dev/null 2>&1 &
sleep 1
if ! ss -ltn 2>/dev/null | grep -q ":$PORT "; then echo "ОШИБКА: фейк-нода не поднялась (python3 есть?)"; exit 1; fi
# 2) запустить воркеров
rm -rf inst
echo "тест: $NW воркеров × 1 поток, ${SECS}с (фейк cuckatoo непрерывно)..."
for ((w=0; w<NW; w++)); do
  INST="$BASE/inst/w$w"; mkdir -p "$INST"
  cat > "$INST/epic-miner.toml" <<TOML
[logging]
log_to_stdout = false
log_to_file = true
file_log_level = "Info"
stdout_log_level = "Info"
log_file_path = "$INST/miner.log"
log_file_append = false
[mining]
algorithm = "Cuckoo"
run_tui = false
stratum_server_addr = "127.0.0.1:$PORT"
stratum_server_tls_enabled = false
miner_plugin_dir = "$BASE/plugins"
[mining.randomx_config]
threads = 1
jit = true
large_pages = false
hard_aes = true
[[mining.gpu_config]]
device = 0
driver = 2
[[mining.miner_plugin_config]]
plugin_name = "cuckatoo_mean_cpu_avx2_19"
[mining.miner_plugin_config.parameters]
nthreads = 1
TOML
  screen -dmS "etest$w" bash -c "cd '$INST'; export LD_LIBRARY_PATH='$BASE/lib'; '$BASE/epic-miner' -c epic-miner.toml"
done
# 3) ждать
sleep $SECS
# 4) результат
echo "=== результат ==="
for d in inst/w*/; do grep -oE 'at [0-9.]+ gps' "$d/miner.log" 2>/dev/null | tail -3 | grep -oE '[0-9.]+' | sort -n | tail -1; done \
  | awk '{s+=$1;n++} END{printf ">>> воркеров=%d  Σ ≈ %.0f gps  (средн %.0f/воркер)\n",n,s,(n?s/n:0)}'
# 5) погасить ВСЁ
for s in $(screen -ls 2>/dev/null | grep -oE 'etest[0-9]+'); do screen -S "$s" -X quit; done
pkill -f "fakestratum.py $PORT" 2>/dev/null
rm -rf inst
echo "(всё выключено, включая фейк-ноду)"

#!/bin/bash
cd /opt/cputest/inst 2>/dev/null || { echo "нет запущенных"; exit; }
for d in ecpu*/; do
  [ -d "$d" ] || continue
  g=$(grep -oE 'at [0-9.]+ gps' "$d/miner.log" 2>/dev/null | tail -3 | grep -oE '[0-9.]+' | sort -n | tail -1)
  printf "  %s: %s gps\n" "${d%/}" "${g:-0}"
done
awk 'BEGIN{s=0}' # noop
for d in ecpu*/; do grep -oE 'at [0-9.]+ gps' "$d/miner.log" 2>/dev/null | tail -3 | grep -oE '[0-9.]+' | sort -n | tail -1; done \
  | awk '{s+=$1} END{printf "  >>> Σ ≈ %.0f gps (пик по каждой карте; 0=не раскрутился/пауза)\n", s}'

#!/bin/bash
# Поднимает N экземпляров РЕАЛЬНОГО epic-miner на CPU. Настраиваемо.
# Usage: ./run_epic_cpu.sh [экземпляров] [nthreads] [ядра|auto] [плагин stock|rebuild]
NW=${1:-4}; NTH=${2:-4}; CORES=${3:-auto}; PL=${4:-stock}
rm -rf /opt/cputest/inst; BASE=/opt/cputest; BINSEL=${6:-patch}; case "$BINSEL" in stock) BIN=/opt/epic-cuckatoo/epic-miner.stock;; *) BIN=/opt/epic-cuckatoo/epic-miner-patch;; esac
ST5=${5:-node}; if [ "$ST5" = fake ]; then STRAT="127.0.0.1:3499"; elif [ "$ST5" = node ]; then STRAT="212.220.216.27:3416"; else STRAT="$ST5"; fi
# выбрать папку плагина (имя файла плагина ДОЛЖНО быть стандартным)
PDIR=$BASE/pl_$PL; mkdir -p $PDIR
case "$PL" in
  stock)   cp -f $BASE/cuckatoo_mean_cpu_avx2_19.cuckooplugin $PDIR/ ;;
  rebuild) cp -f $BASE/mean19_rebuild.cuckooplugin $PDIR/cuckatoo_mean_cpu_avx2_19.cuckooplugin ;;
esac
echo "epic-CPU: экземпляров=$NW nthreads=$NTH ядра=$CORES плагин=$PL стратум=$STRAT"
for ((w=0; w<NW; w++)); do
  INST=$BASE/inst/ecpu$w; mkdir -p $INST
  cat > $INST/epic-miner.toml <<TOML
[logging]
log_to_stdout = false
stdout_log_level = "Info"
log_to_file = true
file_log_level = "Info"
log_file_path = "$INST/miner.log"
log_file_append = false
[mining]
algorithm = "Cuckoo"
run_tui = false
stratum_server_addr = "$STRAT"
stratum_server_tls_enabled = false
miner_plugin_dir = "$PDIR"
[mining.randomx_config]
threads = 1
jit = true
large_pages = false
hard_aes = true
[[mining.gpu_config]]
device = 0
driver = 2
[[mining.miner_plugin_config]]
plugin_name = "cuckatoo_mean_cpu_avx2_19"
[mining.miner_plugin_config.parameters]
nthreads = $NTH
TOML
  screen -S ecpu$w -X quit >/dev/null 2>&1
  if [ "$CORES" = auto ]; then PIN=""; else PIN="taskset -c $CORES "; fi
  screen -dmS ecpu$w bash -c "cd '$INST'; while true; do ${PIN}'$BIN' -c epic-miner.toml; sleep 3; done"
done
echo "запущено. Хешрейт: ./readcpu.sh   | стоп: ./stopcpu.sh"

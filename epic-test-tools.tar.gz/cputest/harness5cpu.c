// harness5cpu: длительный прогон CPU mean-солвера, посекундный g/s (nthreads настраивается)
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <time.h>
typedef uint32_t u32;
typedef struct { u32 nthreads,ntrims; unsigned char showcycle,allrounds,mutate_nonce,cpuload;
  u32 device,blocks,tpb,expand,genablocks,genatpb,genbtpb,trimtpb,tailtpb,recoverblocks,recovertpb; } SolverParams;
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
int main(int c,char**v){
  if(c<2){fprintf(stderr,"usage: %s plugin [nthreads] [secs] [id]\n",v[0]);return 2;}
  const char*p=v[1]; u32 nth=c>2?strtoul(v[2],0,10):1; double secs=c>3?atof(v[3]):30; int id=c>4?atoi(v[4]):0;
  void*h=dlopen(p,RTLD_NOW); if(!h){fprintf(stderr,"dlopen: %s\n",dlerror());return 1;}
  void(*fill)(SolverParams*)=(void(*)(SolverParams*))dlsym(h,"fill_default_params");
  void*(*create)(SolverParams*)=(void*(*)(SolverParams*))dlsym(h,"create_solver_ctx");
  int(*run)(void*,char*,int,u32,u32,void*,void*)=(int(*)(void*,char*,int,u32,u32,void*,void*))dlsym(h,"run_solver");
  SolverParams pr; memset(&pr,0,sizeof pr); fill(&pr); pr.nthreads=nth;
  void*ctx=create(&pr); if(!ctx){fprintf(stderr,"create NULL\n");return 1;}
  char hdr[80]; memset(hdr,0,sizeof hdr);
  double t0=now(), last=t0; u32 nonce=0, cnt=0, lastcnt=0;
  while(now()-t0 < secs){
    run(ctx,hdr,sizeof hdr,nonce++,1,NULL,NULL); cnt++;
    double t=now();
    if(t-last>=1.0){
      printf("cpu%d nthr=%u t=%2.0f inst=%.1f avg=%.1f\n",id,nth,t-t0,(cnt-lastcnt)/(t-last),cnt/(t-t0));
      fflush(stdout); last=t; lastcnt=cnt;
    }
  }
  printf("cpu%d ИТОГ %.1f g/s (nthreads=%u, %u графов за %.0fs)\n",id,cnt/(now()-t0),nth,cnt,secs);
  return 0;
}

#!/bin/bash
PORT=${1:-3499}
pkill -f "fakestratum.py $PORT" 2>/dev/null; sleep 1
cd /opt/cputest
setsid python3 fakestratum.py $PORT >/opt/cputest/fs.log 2>&1 &
sleep 1; cat /opt/cputest/fs.log

#!/bin/bash
BASE="$(cd "$(dirname "$0")"&&pwd)"; . "$BASE/config.env"
N=${WORKERS:-0}; [ "$N" -le 0 ] && N=$(nproc)
INS=${INSTANCES:-1}; [ "$INS" -lt 1 ] && INS=1; PROCS=$(( N / INS )); [ "$PROCS" -lt 1 ] && PROCS=1
NG=$(nvidia-smi -L 2>/dev/null | wc -l)
. "$BASE/aff.sh" "$NG" >/dev/null 2>&1 || true; IFS=',' read -ra CA <<< "${CPUSET:-}"   # CPUSET непустой только если есть GPU
export EPIC_RANGE=${RANGE:-1}; MB="$BASE/bin/epic-miner-${MINER:-range}"
BLK=""; for ((k=0;k<INS;k++)); do BLK+='[[mining.miner_plugin_config]]\nplugin_name = "cuckatoo_mean_cpu_avx2_19"\n[mining.miner_plugin_config.parameters]\nnthreads = 1\n'; done
for ((p=0;p<PROCS;p++)); do
  D="$BASE/inst/w$p"; mkdir -p "$D"
  if [ "$LOGS" = on ] && [ "$p" = 0 ]; then LT=true; else LT=false; fi
  cat > "$D/epic-miner.toml" <<TOML
[logging]
log_to_stdout = false
log_to_file = $LT
file_log_level = "Info"
stdout_log_level = "Info"
log_file_path = "$D/miner.log"
log_file_append = false
[mining]
algorithm = "Cuckoo"
run_tui = false
stratum_server_addr = "127.0.0.1:$PROXY_PORT"
stratum_server_tls_enabled = false
miner_plugin_dir = "$BASE/plugins"
[mining.randomx_config]
threads = 1
jit = true
large_pages = false
hard_aes = true
[[mining.gpu_config]]
device = 0
driver = 2
TOML
  printf "$BLK" >> "$D/epic-miner.toml"
  PIN=""; [ -n "${CA[$p]}" ] && PIN="taskset -c ${CA[$p]} "
  screen -S "wk$p" -X quit 2>/dev/null
  screen -dmS "wk$p" bash -c "cd '$D'; export LD_LIBRARY_PATH='$BASE/lib'; export EPIC_RANGE=${RANGE:-1}; while true; do ${PIN}'$MB' -c epic-miner.toml; sleep 3; done"
done
if [ "$LOGS" = on ]; then screen -S logwatch-cpu -X quit 2>/dev/null; screen -dmS logwatch-cpu "$BASE/logwatch.sh" "$BASE/inst/w0/miner.log"; fi
echo "CPU-воркеры: шт=$PROCS бинарь=${MINER} RANGE=${RANGE} LOGS=${LOGS} пин=$([ -n "${CPUSET:-}" ]&&echo да||echo нет)"

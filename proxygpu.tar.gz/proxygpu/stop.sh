#!/bin/bash
# Остановить ТОЛЬКО proxygpu (майнеры свои — их не трогает).
cd "$(dirname "$0")"; BASE="$(pwd)"
pkill -f "$BASE/bin/epic_proxy.py" 2>/dev/null
screen -S proxygpu-px -X quit 2>/dev/null
echo "proxygpu остановлен"

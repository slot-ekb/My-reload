#!/bin/bash
# Одноразовый статус proxygpu — для HiveOS "Execute command" или быстрого просмотра.
cd "$(dirname "$0")"; . ./config.env 2>/dev/null; NPORT="${NODE##*:}"
echo "===== PROXYGPU $(hostname) ====="
pgrep -f bin/epic_proxy.py >/dev/null && echo "прокси           : РАБОТАЕТ" || echo "прокси           : *** СТОП ***"
echo "воркеров->прокси : $(ss -Htn state established "( dport = :$PROXY_PORT )" 2>/dev/null | wc -l)"
echo "прокси->нода     : $(ss -Htn state established "( dport = :$NPORT )" 2>/dev/null | wc -l)  (нода $NODE)"
echo "--- учёт прокси ---"
grep 'СТАТ' logs/proxy.log 2>/dev/null | tail -1 | sed 's/^[0-9:]* СТАТ/ /'

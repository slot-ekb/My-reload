#!/bin/bash
# proxygpu: поднимает ТОЛЬКО прокси (-> нода). GPU-майнеры свои, направляй их на :PROXY_PORT.
cd "$(dirname "$0")"; BASE="$(pwd)"; . ./config.env
mkdir -p logs

if [ "$NODE" = "ВПИШИ_IP:3416" ] || [ -z "$NODE" ]; then
  echo "!!! Впиши адрес ноды в config.env (NODE=\"IP:3416\") и запусти снова."; exit 1
fi

pkill -f "$BASE/bin/epic_proxy.py" 2>/dev/null; screen -S proxygpu-px -X quit 2>/dev/null; sleep 1
screen -dmS proxygpu-px bash -c "cd '$BASE'; while true; do python3 -u bin/epic_proxy.py $NODE $PROXY_PORT >> logs/proxy.log 2>&1; echo '--- прокси перезапуск ---' >> logs/proxy.log; sleep 3; done"
sleep 2
if pgrep -f "$BASE/bin/epic_proxy.py" >/dev/null || pgrep -f "bin/epic_proxy.py" >/dev/null; then
  echo "proxygpu поднят: -> $NODE, слушает :$PROXY_PORT"
  echo "направь GPU-майнеры на  <IP_рига>:$PROXY_PORT  (или 127.0.0.1:$PROXY_PORT локально)"
  echo "смотреть: ./stat.sh   |   стоп: ./stop.sh"
else
  echo "ПРОКСИ не стартовал:"; tail -5 logs/proxy.log; exit 1
fi

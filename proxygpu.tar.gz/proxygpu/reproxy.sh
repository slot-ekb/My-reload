#!/bin/bash
# Перезапуск proxygpu (майнеры не трогаем — переподключатся за 1-2с).
cd "$(dirname "$0")"; BASE="$(pwd)"; . ./config.env
pkill -f "$BASE/bin/epic_proxy.py" 2>/dev/null
screen -S proxygpu-px -X quit 2>/dev/null
sleep 1
screen -dmS proxygpu-px bash -c "cd '$BASE'; while true; do python3 -u bin/epic_proxy.py $NODE $PROXY_PORT >> logs/proxy.log 2>&1; echo '--- прокси перезапуск ---' >> logs/proxy.log; sleep 3; done"
sleep 2
if pgrep -f "bin/epic_proxy.py" >/dev/null; then
  echo "proxygpu перезапущен (майнеры не тронуты)"
else
  echo "прокси не поднялся:"; tail -3 logs/proxy.log
fi
